Raspberry Pi B+ / 2 / 3 / 3B+ Camera with cutouts for CAM/GPIO and optional camera mount by maciejb on Thingiverse: https://www.thingiverse.com/thing:685074
